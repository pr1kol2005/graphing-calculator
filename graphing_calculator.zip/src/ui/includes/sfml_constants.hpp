#pragma once

#include <SFML/Graphics.hpp>

const sf::Color DEFAULT_COLOR = sf::Color::Blue;